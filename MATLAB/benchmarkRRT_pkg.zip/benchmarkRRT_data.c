/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * benchmarkRRT_data.c
 *
 * Code generation for function 'benchmarkRRT_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "benchmarkRRT.h"
#include "benchmarkRRT_data.h"

/* Variable Definitions */
unsigned int state[625];
const double dv0[5] = { 3.0, 3.0, 2.0, 3.5, 3.0 };

/* End of code generation (benchmarkRRT_data.c) */
