/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * benchmarkRRT_initialize.h
 *
 * Code generation for function 'benchmarkRRT_initialize'
 *
 */

#ifndef BENCHMARKRRT_INITIALIZE_H
#define BENCHMARKRRT_INITIALIZE_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "benchmarkRRT_types.h"

/* Function Declarations */
extern void benchmarkRRT_initialize(void);

#endif

/* End of code generation (benchmarkRRT_initialize.h) */
