/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * benchmarkRRT_terminate.c
 *
 * Code generation for function 'benchmarkRRT_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "benchmarkRRT.h"
#include "benchmarkRRT_terminate.h"

/* Function Definitions */
void benchmarkRRT_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (benchmarkRRT_terminate.c) */
